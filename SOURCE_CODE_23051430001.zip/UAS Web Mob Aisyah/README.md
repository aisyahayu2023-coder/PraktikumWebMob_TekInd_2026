# UTS Perbaikan - Aplikasi Web React
## PT Manufaktur Jaya Abadi - Sistem Manajemen Shift & Laporan Produksi Harian

---

## Identitas Mahasiswa

| **Nama** | Aisyah Ayu Salsabila|
|----------|-------------------------|
| **NIM**  | [23051430001] |
| **Kelas** | S1 Teknik Industri |
| **Mata Kuliah** | Aplikasi Web dan Mobile (IDT60248) |

---

## Deskripsi Aplikasi

Aplikasi ini adalah sistem manajemen laporan produksi harian untuk PT Manufaktur Jaya Abadi. Dibangun dengan **React.js** dan **Vite** sebagai build tool.

Fitur utama:
- Manajemen data produksi (Create, Read, Delete)
- Perhitungan otomatis Netto dan Yield
- Dashboard dengan KPI (Total Produksi, Total Reject, Yield Rata-rata)
- Penyimpanan data dengan **LocalStorage** (data persist meskipun browser ditutup)
- Desain responsif dengan **Bootstrap 5**
- Routing antar halaman dengan **React Router DOM**

---

## Fitur Lengkap

### Checkpoint 1 (HTML/CSS + Routing)
- ✅ Routing 3 halaman (Dashboard, Input Laporan, Riwayat Data)
- ✅ Navbar dengan Link (tanpa reload)
- ✅ Halaman Dashboard dengan 3 KPI Card (Bootstrap)
- ✅ Halaman Input dengan 5 field form + dropdown Shift (Pagi, Siang, Malam)
- ✅ Halaman Riwayat dengan tabel 9 kolom
- ✅ Responsif di lebar 768px

### Checkpoint 2 (Logika JavaScript & State)
- ✅ useState untuk setiap field form
- ✅ Kalkulasi real-time Netto dan Yield
- ✅ Validasi (Reject tidak boleh > Produksi) → border merah + pesan error
- ✅ Tombol Simpan disabled jika data tidak valid
- ✅ Spread operator untuk menambah data di paling atas
- ✅ Fungsi hapus dengan filter
- ✅ Dashboard KPI berubah sesuai data

### Checkpoint 3 (LocalStorage & Persistensi)
- ✅ Data tersimpan ke LocalStorage dengan key `DATA_LAPORAN_PRODUKSI`
- ✅ Data dimuat saat aplikasi pertama kali dibuka (useEffect)
- ✅ Data tidak hilang saat refresh browser
- ✅ Data tidak hilang saat browser ditutup dan dibuka kembali
- ✅ Tombol Hapus Semua dengan konfirmasi

### Checkpoint 4 (Demo + Modifikasi)
- ✅ Demo semua fitur lengkap
- ✅ Modifikasi (KPI Yield merah jika rata-rata Yield < 85%)
  - Yield rata-rata < 85% → card berwarna **MERAH**
  - Yield rata-rata ≥ 85% → card berwarna **HIJAU**

---

## Struktur Folder
UAS_Web_Mob_Aisyah/
├── src/
│ ├── components/
│ │ └── Navbar.jsx
│ ├── pages/
│ │ ├── Dashboard.jsx
│ │ ├── InputLaporan.jsx
│ │ └── RiwayatData.jsx
│ ├── utils/
│ │ └── storage.js
│ ├── App.jsx
│ ├── main.jsx
│ └── index.css
├── index.html
├── package.json
├── package-lock.json
├── vite.config.js
└── README.md

## Cara Menjalankan
1. Buka terminal di folder ini
2. Jalankan `npm install`
3. Jalankan `npm run dev`
4. Buka browser ke `http://localhost:5173`

## Fitur Unggulan
- Yield card berwarna MERAH jika rata-rata yield < 85% 
- Data persist di LocalStorage (tidak hilang meskipun browser ditutup)
- Validasi real-time dengan border merah dan disabled button