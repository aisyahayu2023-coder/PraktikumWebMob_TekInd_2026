import { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import InputLaporan from './pages/InputLaporan';
import RiwayatData from './pages/RiwayatData';
import 'bootstrap/dist/css/bootstrap.min.css';
import { saveToStorage, loadFromStorage } from './utils/storage';

function App() {
  const [laporanList, setLaporanList] = useState (()=> {
    const savedData = loadFromStorage();
    return savedData;
  });
  useEffect(() => {
    saveToStorage(laporanList);
  }, [laporanList]);

  return (
    <>
      <Navbar />
      <div className='container mt-4'>
        <Routes>
          <Route path="/" element={<Dashboard laporanList={laporanList} />} />
          <Route path="/input" element={<InputLaporan laporanList={laporanList} setLaporanList={setLaporanList} />} />
          <Route path="/riwayat" element={<RiwayatData laporanList={laporanList} setLaporanList={setLaporanList} />} />
        </Routes>
      </div>
    </>
  );
}

export default App;