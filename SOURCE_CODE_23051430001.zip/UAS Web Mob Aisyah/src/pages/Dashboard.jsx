function Dashboard({ laporanList = [] }) {
  const dataList = Array.isArray(laporanList) ? laporanList : [];
  const totalProduksi = dataList.reduce((sum, item) => {
    return sum + (Number(item.produksi) || 0);
  }, 0);
  
  const totalReject = dataList.reduce((sum, item) => {
    return sum + (Number(item.reject) || 0);
  }, 0);
  
  let avgYield = 0;
  if (dataList.length > 0) {
    let totalYield = 0;
    for (let i = 0; i < dataList.length; i++) {
      totalYield = totalYield + (Number(dataList[i].yield) || 0);
    }
    avgYield = totalYield/laporanList.length;
    avgYield = avgYield.toFixed(1);
  }
  let warnaYield = "bg-success";
  if (avgYield<85) {
    warnaYield = "bg-danger";
  }
  return (
    <div>
      <h2 className="mb-4">Dashboard Produksi</h2>
      <div className="row">
        <div className="col-md-4">
          <div className="card text-white bg-primary mb-3">
            <div className="card-body">
              <h5 className="card-title">Total Produksi</h5>
              <p className="display-6">{totalProduksi}</p>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card text-white bg-danger mb-3">
            <div className="card-body">
              <h5 className="card-title">Total Reject</h5>
              <p className="display-6">{totalReject}</p>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className={`card text-white ${warnaYield} mb-3`}> 
            <div className="card-body">
              <h5 className="card-title">Yield Rata-rata</h5>
              <p className="display-6">{dataList.length === 0 ? 0 : avgYield}%</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;