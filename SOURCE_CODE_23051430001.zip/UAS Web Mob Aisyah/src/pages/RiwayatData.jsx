import { useState } from "react";

function RiwayatData({ laporanList, setLaporanList }) {
  const handleDelete = (id) => {
    if (window.confirm('Yakin akan menghapus data ini?')) {
      const newList = laporanList.filter(item => item.id !== id);
      setLaporanList(newList);
    }
  };
  const handleDeleteAll = () => {
    if (window.confirm('Hapus Semua Data?')) {
        setLaporanList([]);
    }
  };
  return (
    <div>
      <h2 className="mb-4">Riwayat Produksi</h2>
      <div className="table-responsive">
        <div className="mb-3">
        <button className="btn btn-danger" onClick={handleDeleteAll}>
            Hapus Semua 
        </button>
        </div>
        <table className="table table-striped table-bordered">
          <thead className="table-dark">
            <tr>
              <th>No</th>
              <th>Tanggal</th>
              <th>Shift</th>
              <th>Mesin</th>
              <th>Produksi</th>
              <th>Reject</th>
              <th>Netto</th>
              <th>Yield (%)</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {laporanList.length === 0 ? (  
              <tr>
                <td colSpan="9" className="text-center">Belum ada data</td>
              </tr>
            ) : (
              laporanList.map((item, idx) => (
                <tr key={item.id}>
                  <td>{idx + 1}</td>
                  <td>{item.tanggal}</td>
                  <td>{item.shift}</td>
                  <td>{item.mesin}</td>
                  <td>{item.produksi}</td>
                  <td>{item.reject}</td>
                  <td>{item.netto}</td>
                  <td>{item.yield}%</td>
                  <td>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(item.id)}>
                      Hapus
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default RiwayatData;