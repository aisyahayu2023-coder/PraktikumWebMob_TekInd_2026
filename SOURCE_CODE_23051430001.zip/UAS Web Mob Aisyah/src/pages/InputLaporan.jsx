import { useState } from "react";
import { useNavigate } from "react-router-dom";

function InputLaporan({ laporanList, setLaporanList }) {  
    const navigate = useNavigate();
    const [tanggal, setTanggal] = useState(new Date().toISOString().split('T')[0]);
    const [shift, setShift] = useState('Pagi');
    const [mesin, setMesin] = useState('');
    const [produksi, setProduksi] = useState('');
    const [reject, setReject] = useState('');

    const produksiNum = Number(produksi) || 0;
    const rejectNum = Number(reject) || 0;
    const netto = produksiNum - rejectNum;
    const yieldValue = produksiNum > 0 ? ((produksiNum - rejectNum) / produksiNum * 100).toFixed(1) : 0;
    const isValid = tanggal && shift && mesin && produksiNum > 0 && rejectNum <= produksiNum;

    const handleSubmit = (e) => {
        e.preventDefault();
        if (isValid) {
            const newData = {
                id: Date.now(),
                tanggal,
                shift,
                mesin,
                produksi: produksiNum,
                reject: rejectNum,
                netto,
                yield: yieldValue
            };
            setLaporanList([newData, ...laporanList]);  
            navigate('/riwayat');
        }
    };

    return (
        <div className="card">
            <div className="card-header bg-primary text-white">
                <h4>Input Laporan Produksi</h4>
            </div>
            <div className="card-body">
                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label className="form-label">Tanggal</label>
                        <input type="date" className="form-control" value={tanggal} onChange={(e) => setTanggal(e.target.value)} required />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Shift</label>
                        <select className="form-control" value={shift} onChange={(e) => setShift(e.target.value)} required>
                            <option>Pagi</option>
                            <option>Siang</option>
                            <option>Malam</option>
                        </select>
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Nama Mesin</label>
                        <input type="text" className="form-control" value={mesin} onChange={(e) => setMesin(e.target.value)} required />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Jumlah Produksi</label>
                        <input type="number" className="form-control" value={produksi} onChange={(e) => setProduksi(e.target.value)} required />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Jumlah Reject</label>
                        <input type="number" className={`form-control ${rejectNum > produksiNum ? 'is-invalid' : ''}`} value={reject} onChange={(e) => setReject(e.target.value)} required />
                        {rejectNum > produksiNum && <div className="invalid-feedback">Reject tidak boleh melebihi Produksi!</div>}
                    </div>
                    <div className="mb-3 alert alert-info">
                        Netto: <strong>{netto}</strong> | Yield: <strong>{yieldValue}%</strong>
                    </div>
                    <button type="submit" className="btn btn-primary w-100" disabled={!isValid}>Simpan</button>
                </form>
            </div>
        </div>
    );
}

export default InputLaporan;