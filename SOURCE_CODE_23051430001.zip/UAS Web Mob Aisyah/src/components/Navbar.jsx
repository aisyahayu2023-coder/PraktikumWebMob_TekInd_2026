import { Link } from "react-router-dom";

function Navbar () {
    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="container">
                <Link className="navbar-brand" to="/">PT Manufaktur Jaya Abadi</Link>
                <div className="collapse navbar-collapse">
                    <ul className="navbar-nav ms-auto">
                      <li className="nav-item">
                        <Link className="nav-link" to="/">Dashboard</Link>
                      </li>
                      <li className="nav-item">
                        <Link className="nav-link" to="/input">Input Laporan</Link>
                      </li>
                      <li className="nav-item">
                        <Link className="nav-link" to="/riwayat">Riwayat Data</Link>
                      </li>
                    </ul>
                </div>
            </div>
        </nav>
    );
}
export default Navbar